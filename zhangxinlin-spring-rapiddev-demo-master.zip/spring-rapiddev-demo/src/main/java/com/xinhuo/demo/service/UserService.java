package com.xinhuo.demo.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.xinhuo.demo.model.User;

/**
 * author 张新林
 * 时间 2019/1/20 18:08
 * 描述
 */
public interface UserService extends IService<User> {

}
