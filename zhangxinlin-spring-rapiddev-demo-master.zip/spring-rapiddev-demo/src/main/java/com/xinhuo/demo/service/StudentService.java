package com.xinhuo.demo.service;

import com.xinhuo.demo.model.Student;
import com.baomidou.mybatisplus.extension.service.IService;


/**
 * 描述: 
 * author: 新林
 * date: 2019-06-16
 */
public interface StudentService extends IService<Student> {

}
