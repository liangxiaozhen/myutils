
package com.xinhuo.demo;


public interface Constants
{
	int PAGE_SIZE = 5;
}
