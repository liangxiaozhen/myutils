package com.xinhuo.demo.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xinhuo.demo.model.Student;

/**
 * 描述: 
 * author: 新林
 * date: 2019-06-16
 */
public interface StudentMapper extends BaseMapper<Student> {

}