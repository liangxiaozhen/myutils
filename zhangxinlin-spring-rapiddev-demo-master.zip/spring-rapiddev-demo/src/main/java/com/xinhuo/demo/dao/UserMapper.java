package com.xinhuo.demo.dao;



import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xinhuo.demo.model.User;

public interface UserMapper extends BaseMapper<User> {

}