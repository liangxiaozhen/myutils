# spring-rapiddev-demo

#### 介绍
springboot+mybatis-plus的demo项目

#### 软件架构
软件架构说明

配套代码生成器，快速搭建项目<br>
<a href="https://blog.csdn.net/qq_21187515/article/details/92182434">简单java代码生成器的开发教程(一)，根据数据库表逆向工程生成实体类</a>

<a href="https://blog.csdn.net/qq_21187515/article/details/92182816">简单java代码生成器的开发教程(二)，生成springboot+mybatis-plus的增删查改的基本代码（开发利器，附源码）</a>