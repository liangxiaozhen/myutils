package com.xinlin.code.generate.config;

/**
 * author 张新林
 * 时间 2019/6/12 0:06
 * 描述
 */
public interface ITypeConvert {
    DbColumnType processTypeConvert(String var1);
}
